"""
Entry point. Sets up core services, checks first run, opens PyWebView window.
"""

import logging
import os
import sys
import threading
from pathlib import Path

import webview

from core.settings import Settings
from core.events import EventBus
from core.api import API
from core.first_run import needs_first_run

APP_ROOT = Path(__file__).parent
LOG_FORMAT = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"

logging.basicConfig(
    level=logging.INFO,
    format=LOG_FORMAT,
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(APP_ROOT / "app.log", encoding="utf-8"),
    ],
)
log = logging.getLogger("MyAIAgentHub")

settings = Settings(APP_ROOT / "settings.json")
bus = EventBus()
api = API(settings, bus, APP_ROOT, log)

window = webview.create_window(
    title="MyAI Agent Hub",
    url=str(APP_ROOT / "frontend" / "index.html"),
    js_api=api,
    width=1280,
    height=820,
    min_size=(1024, 660),
    background_color="#0f0f0f",
)

api.set_window(window)


def _on_loaded():
    if needs_first_run(settings):
        window.evaluate_js("window.showFirstRun()")
    else:
        start = settings.get("start_tab", "chat")
        window.evaluate_js(f"window.navigate('{start}')")


def _on_closing():
    def _cleanup():
        log.info("Window closing — shutting down services…")
        api.shutdown()
        log.info("Shutdown complete.")

    t = threading.Thread(target=_cleanup, daemon=True)
    t.start()
    t.join(timeout=4)


window.events.loaded += _on_loaded
window.events.closing += _on_closing

webview.start(debug=os.environ.get("MYAI_DEBUG", "").lower() in ("1", "true", "yes"))
